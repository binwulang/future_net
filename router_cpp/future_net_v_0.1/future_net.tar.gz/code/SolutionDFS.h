/*
 * SolutionDFS.h
 *
 *  Created on: 2016年3月24日
 *      Author: yaobin
 */

#ifndef SRC_SOLUTIONDFS_H_
#define SRC_SOLUTIONDFS_H_
#include <set>
#include "Graph.h"
class Solution_DFS {
	vector<int> path ;
	int Min_Cost;
	set<int> *IncVertexs;
	Graph *graph;
	bool *inc_node;
public:
	Solution_DFS();
	virtual ~Solution_DFS();
	vector<int> * GetPath();
	void DFS(int StartID, int EndID,int Cost,vector<int>* path,int IncNode_Count);
	void FindPath(int StartID, int EndID,set<int>* IncVertexs,Graph *graph);
};

#endif /* SRC_SOLUTIONDFS_H_ */
